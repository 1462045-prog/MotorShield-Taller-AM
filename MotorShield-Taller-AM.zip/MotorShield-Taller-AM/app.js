const MODO_AUTOPILOTO_DAW = true;

document.addEventListener("DOMContentLoaded", () => {
    console.log("MotorShield Taller - AM está listo.");
});