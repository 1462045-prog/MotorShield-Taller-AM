
# Informe final — MotorShield Taller - AM

## 1. Descripción del proyecto
Panel web para gestionar, consultar y clasificar incidencias de un taller mecánico.

## 2. Tecnologías utilizadas
- HTML5
- CSS3
- JavaScript ES6
- JSON
- localStorage

## 3. Seguridad y privacidad
- Anonimización de datos personales.
- Protección de matrículas e IBAN.
- Detección de intentos de prompt injection.
- Validación de entradas.

## 4. Funcionalidades
- Registro de incidencias.
- Clasificación de tickets.
- Búsqueda y filtrado.
- Vista previa protegida.
- Persistencia local.

## 5. Pruebas realizadas
Indicar las pruebas ejecutadas y sus resultados reales.

## 6. Conclusión
El proyecto permite gestionar incidencias mediante una interfaz web,
aplicando medidas didácticas de privacidad y protección de datos.
